# Synthetic demonstration data

These are **simulated counts**, not patient data or a biological finding.

- 2,000 artificial features (`DEMO00001` ... `DEMO02000`).
- Eight simulated samples: four `control` and four `treated`.
- Two balanced artificial batches (`A`, `B`).
- Counts drawn from negative-binomial distributions with library-size variation.
- Generating log2 effects: +2 for the first 200 features, -2 for the next 150,
  zero for the remainder. The final 20 rows are zero to exercise prefiltering.
- Seed: `20261028`. Regenerate with `python scripts/make_demo.py` (NumPy required).

The R pipeline uses the committed TSV files and does not require Python.
Synthetic truth is not evidence of accuracy on real experiments. No analysis
outputs or performance claims are supplied before running the R pipeline.
