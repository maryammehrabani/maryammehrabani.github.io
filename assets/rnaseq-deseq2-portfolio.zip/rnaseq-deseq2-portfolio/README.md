# Bulk RNA-seq differential expression with DESeq2

A compact R portfolio project for **Maryam Mehrabani**: validated count-matrix
inputs, an explicit treatment-versus-control comparison, optional batch adjustment,
QC figures, result tables and an audit trail.

**Status:** ready for local execution and review. R is unavailable in the authoring
environment, so the DESeq2 analysis and R tests have **not** been executed here.
Demo TSV structure, package contents and deterministic data generation were checked
with Python. See [VALIDATION.md](VALIDATION.md). Do not describe this as a validated
production pipeline until its R tests and real-data review have passed.

This is a **new reusable template**, not the code behind the separate AML/limma
thesis-figure collection. The included data are synthetic. No biological results
or benchmark performance are claimed.

## Quick start

Install R and its matching Bioconductor release. Run the following from this
repository's root directory (or use the RStudio terminal):

```sh
Rscript scripts/setup.R
Rscript tests/test_validation.R
Rscript scripts/run_deseq2.R --counts data/demo/counts.tsv --samples data/demo/samples.tsv --control control --treatment treated --batch batch --out results/demo
Rscript tests/smoke_test.R
```

For your own two-group study, replace the paths and condition labels. The output
directory must be new or empty; prior runs are never silently overwritten.

```sh
Rscript scripts/run_deseq2.R --counts data/private/counts.tsv --samples data/private/samples.tsv --control control --treatment treated --batch none --out results/study-01
```

Check input validity without installing DESeq2:

```sh
Rscript scripts/run_deseq2.R --counts data/demo/counts.tsv --samples data/demo/samples.tsv --control control --treatment treated --batch batch --out results/check --validate-only
```

## Input contract

`counts.tsv`: a tab-separated raw gene-count table, one unique gene ID per row.

```text
gene_id    control_1    control_2    treated_1    treated_2
GENE_A     125          140          360          290
GENE_B     75           98           23           30
```

The example above illustrates structure only, not sufficient data for a full run.
Use tabs, not spaces. Counts must be finite, nonnegative integers. **Do not use TPM,
FPKM, RPKM, log expression, microarray intensities or rounded normalized values.**
Numeric validation cannot detect every wrongly supplied integer-valued normalized
matrix; the analyst must confirm provenance. Use the dedicated `tximport`/`tximeta`
route for transcript quantifier estimates; it is outside this template's scope.

`samples.tsv`: unique `sample_id` and `condition` columns, plus an optional batch
column. Sample IDs must match count headers exactly. Metadata are explicitly
reordered to match the count columns.

```text
sample_id    condition    batch
control_1    control      A
control_2    control      B
treated_1    treated      A
treated_2    treated      B
```

This template requires exactly two named conditions, at least two independent
biological replicates per group and residual degrees of freedom. Three or more
replicates are preferable; adequate sample size depends on the study. Technical
replicates do not replace independent biological replication. Paired, longitudinal,
interaction and pseudobulk designs require an adapted model.

## Analysis choices

| Choice | Implementation |
|---|---|
| Direction | `treatment - control`; positive log2FC means higher in treatment |
| Design | `~ condition`, or `~ model_batch + condition` using the chosen batch column |
| Design safety | Reject missing IDs, duplicate features, confounded/non-full-rank and saturated designs |
| Prefilter | At least 10 counts in at least the smaller group's sample count, configurable |
| Fit | DESeq2 negative-binomial model, two-sided Wald test of log2FC = 0 |
| Multiplicity | BH-adjusted P; independent filtering enabled at the chosen alpha |
| Outliers | DESeq2 Cook's cutoff retained; automatic count replacement disabled |
| Default selection | `padj < 0.05`, then descriptive `abs(raw log2FC) >= 1` |
| QC transform | VST with `blind=FALSE`; top 500 variable retained genes for PCA |
| Reproducibility | Source/input MD5, aligned metadata, design matrix, config, R session, warnings and fitted objects |

The effect cutoff is **a posthoc descriptive filter**, not a statistical test that
an effect exceeds 1. To test an effect-size hypothesis, adapt `results()` with an
appropriate `lfcThreshold` and `altHypothesis` and document that separate analysis.
No raw-P threshold is added to the default BH filter.

Low-count removal and missing p-values remain visible in `results_all_genes.tsv`.
`test_status` distinguishes prefilter removal, independent filtering, Cook's
outliers (where identifiable) and other unavailable p-values. A diagnostic result
with Cook's filtering disabled is used only to identify NA reasons, never to
replace reported inference. The run stops if coefficient fits do not converge.
`beta_converged` is retained for audit; review warnings before interpreting results.

VST and size-factor-normalized counts do **not** remove batch effects. Batch is
accounted for in the differential-expression model; uncorrected QC displays may
still show batch structure. PCA is exploratory QC, not diagnostic validation.

## Optional effect shrinkage

```sh
Rscript scripts/setup.R --with-apeglm
Rscript scripts/run_deseq2.R --counts data/demo/counts.tsv --samples data/demo/samples.tsv --control control --treatment treated --batch batch --shrink apeglm --out results/demo-shrunk
```

Shrunken effects are exported separately as `log2FC_shrunken`. Statistical testing,
the default posthoc filter and volcano x-axis continue to use unshrunken effects;
the shrunken column is for exploration and ranking. The additive binary design
places the condition coefficient last and records the exact coefficient name.

`--size-factors poscounts` is an explicit alternative for sparse matrices where the
default geometric-mean method cannot estimate size factors. Do not use it as a
substitute for investigating poor library quality or an inappropriate assay.

## Main outputs

| File | Use |
|---|---|
| `results_all_genes.tsv` | Every input feature, ranked by BH P, with removal/NA status |
| `results_selected_posthoc.tsv` | Features meeting the declared FDR and descriptive effect filter |
| `pca.pdf`, `sample_distances.pdf` | Sample-level exploratory QC |
| `volcano.pdf`, `ma.pdf`, `dispersion.pdf` | Effects, uncertainty-related summaries and model fit |
| `sample_qc.tsv`, `samples_aligned.tsv`, `design_matrix.tsv` | Sample and design audit |
| `normalized_counts_retained.tsv`, `vst_values_retained.tsv` | Visualization inputs; do not reuse as DESeq2 counts |
| `dds.rds`, `vst.rds` | Fitted model and transformed object |
| `run_config.tsv`, `input_source_checksums.tsv`, `sessionInfo.txt` | Provenance |
| `summary.txt`, `warnings.txt`, `run_status.txt` | Run outcome and interpretation checks |

## Scope and limits

This project starts at **gene counts**. FASTQ QC, reference choice, alignment,
quantification, gene annotation, pathway enrichment and single-cell analysis are
not implemented. Gene IDs are not silently collapsed or converted. Confirm
strandedness, counting settings, annotation version and biological independence
upstream. Review warnings and all QC plots before drawing conclusions.

For a stronger public portfolio, add a permitted public real-data example,
accession and sample provenance, executed outputs, a concise interpretation and
a captured environment after validation. `sessionInfo()` records each run; it
does not lock package versions. An `renv.lock` should only be added after resolving
and testing a real environment. Never upload confidential patient-level data.

## References

- [Official DESeq2 vignette](https://www.bioconductor.org/packages/release/bioc/vignettes/DESeq2/inst/doc/DESeq2.html).
- Love MI, Huber W, Anders S. 2014. Moderated estimation of fold change and dispersion
  for RNA-seq data with DESeq2. *Genome Biology* 15:550.
  [doi:10.1186/s13059-014-0550-8](https://doi.org/10.1186/s13059-014-0550-8).
- Zhu A, Ibrahim JG, Love MI. 2019. Heavy-tailed prior distributions for sequence
  count data: removing the noise and preserving large differences.
  *Bioinformatics* 35:2084-2092. [doi:10.1093/bioinformatics/bty895](https://doi.org/10.1093/bioinformatics/bty895).

New template code and synthetic data were prepared with AI assistance for review
and customization. Third-party packages retain their own licenses. Choose an
appropriate license for this repository before public release; none is imposed
on your work by this package.

[راهنمای فارسی انتشار در GitHub](GUIDE_FA.md)
