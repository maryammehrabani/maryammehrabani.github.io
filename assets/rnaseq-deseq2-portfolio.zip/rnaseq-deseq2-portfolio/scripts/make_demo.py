#!/usr/bin/env python3
"""Regenerate synthetic demo inputs. Requires NumPy; not needed to run R analysis.

No human samples, published measurements or genuine gene identifiers are used.
"""
from pathlib import Path
import csv
import numpy as np

DEST = Path(__file__).resolve().parents[1] / "data" / "demo"
DEST.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(20261028)
n_genes = 2000
sample_ids = [f"control_{i}" for i in range(1, 5)] + [f"treated_{i}" for i in range(1, 5)]
conditions = ["control"] * 4 + ["treated"] * 4
batches = ["A", "A", "B", "B"] * 2
baseline = np.exp(rng.normal(4.2, 1.1, n_genes))
dispersion = rng.uniform(0.08, 0.20, n_genes)
true_lfc = np.zeros(n_genes)
true_lfc[:200] = 2.0
true_lfc[200:350] = -2.0
library_factors = np.array([0.8, 1.1, 1.0, 1.2, 1.05, 0.9, 1.15, 0.85])
counts = np.empty((n_genes, 8), dtype=np.int64)
for j, condition in enumerate(conditions):
    mu = baseline * library_factors[j]
    if condition == "treated":
        mu = mu * (2 ** true_lfc)
    if batches[j] == "B":
        mu = mu * np.where(np.arange(n_genes) % 7 == 0, 1.5, 1.0)
    size = 1.0 / dispersion
    counts[:, j] = rng.negative_binomial(size, size / (size + mu))
counts[-20:, :] = 0
with (DEST / "counts.tsv").open("w", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(["gene_id"] + sample_ids)
    for i, row in enumerate(counts):
        w.writerow([f"DEMO{i+1:05d}"] + row.tolist())
with (DEST / "samples.tsv").open("w", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(["sample_id", "condition", "batch"])
    w.writerows(zip(sample_ids, conditions, batches))
print(f"Wrote synthetic {n_genes}-gene, 8-sample demo to {DEST}")
