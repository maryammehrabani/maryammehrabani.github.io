#!/usr/bin/env Rscript
# Two-group bulk RNA-seq from raw gene counts. See README for assumptions.
argv <- commandArgs(trailingOnly = TRUE)
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- normalizePath(sub("^--file=", "", script_arg[1L]), mustWork = TRUE)
source(file.path(dirname(script_path), "validation.R"))
usage <- function() cat(paste(
  "Usage: Rscript scripts/run_deseq2.R --counts counts.tsv --samples samples.tsv",
  "  --control control --treatment treated --out results/run1",
  "  [--batch none|column] [--alpha 0.05] [--lfc-threshold 1]",
  "  [--min-count 10] [--min-samples auto|integer]",
  "  [--size-factors ratio|poscounts] [--shrink none|apeglm] [--validate-only]",
  sep = "\n"), "\n")
if ("--help" %in% argv || !length(argv)) { usage(); quit(status = 0L) }
validate_only <- "--validate-only" %in% argv
argv <- argv[argv != "--validate-only"]
if (!length(argv)) fail("Missing required options. Use --help.")
if (length(argv) %% 2L) fail("Every option except --validate-only needs a value. Use --help.")
keys <- sub("^--", "", argv[seq(1L, length(argv), by = 2L)])
if (anyDuplicated(keys) || any(!startsWith(argv[seq(1L, length(argv), by = 2L)], "--"))) fail("Invalid or repeated options.")
opts <- list(batch = "none", alpha = "0.05", `lfc-threshold` = "1", `min-count` = "10",
             `min-samples` = "auto", `size-factors` = "ratio", shrink = "none")
allowed <- c(names(opts), "counts", "samples", "control", "treatment", "out")
if (any(!keys %in% allowed)) fail("Unknown option: ", paste(keys[!keys %in% allowed], collapse = ", "))
opts[keys] <- as.list(argv[seq(2L, length(argv), by = 2L)])
required <- c("counts", "samples", "control", "treatment", "out")
if (!all(required %in% names(opts))) fail("Missing required options. Use --help.")
if (any(!nzchar(unlist(opts)))) fail("Option values cannot be empty.")
alpha <- suppressWarnings(as.numeric(opts$alpha))
lfc_cut <- suppressWarnings(as.numeric(opts[["lfc-threshold"]]))
if (!is.finite(alpha) || alpha <= 0 || alpha >= 1) fail("alpha must be between 0 and 1.")
if (!is.finite(lfc_cut) || lfc_cut < 0) fail("lfc-threshold must be nonnegative.")
if (!opts[["size-factors"]] %in% c("ratio", "poscounts")) fail("size-factors must be ratio or poscounts.")
if (!opts$shrink %in% c("none", "apeglm")) fail("shrink must be none or apeglm.")
min_samples <- if (opts[["min-samples"]] == "auto") NULL else suppressWarnings(as.numeric(opts[["min-samples"]]))
inp <- validate_inputs(opts$counts, opts$samples, opts$control, opts$treatment,
                       opts$batch, suppressWarnings(as.numeric(opts[["min-count"]])), min_samples)
if (validate_only) {
  cat("VALID INPUTS\n", nrow(inp$counts), "genes;", ncol(inp$counts), "samples;",
      sum(inp$keep), "genes pass the count filter.\n")
  print(inp$group_sizes); print(inp$design); quit(status = 0L)
}
needed <- c("DESeq2", if (opts$shrink == "apeglm") "apeglm")
missing <- needed[!vapply(needed, requireNamespace, quietly = TRUE, FUN.VALUE = logical(1))]
if (length(missing)) fail("Missing packages: ", paste(missing, collapse = ", "), ". Run scripts/setup.R.")
suppressPackageStartupMessages(library(DESeq2))
out <- opts$out
if (file.exists(out) && !dir.exists(out)) fail("Output path is a file.")
if (dir.exists(out) && length(list.files(out, all.files = TRUE, no.. = TRUE))) {
  fail("Output directory is not empty; choose a new path to preserve previous runs.")
}
if (!dir.exists(out) && !dir.create(out, recursive = TRUE)) fail("Cannot create output directory.")
out <- normalizePath(out)
write_tsv <- function(x, name) write.table(x, file.path(out, name), sep = "\t", quote = FALSE,
                                          row.names = FALSE, na = "NA")
matrix_tsv <- function(x, name, first = "gene_id") {
  d <- data.frame(rownames(x), x, check.names = FALSE); names(d)[1L] <- first
  write_tsv(d, name)
}
save_plot <- function(name, draw, width = 8, height = 6) {
  grDevices::pdf(file.path(out, name), width = width, height = height, useDingbats = FALSE)
  on.exit(grDevices::dev.off())
  par(family = "sans", col = "#243840", col.axis = "#243840", col.lab = "#243840",
      mar = c(4.5, 4.5, 3, 1), las = 1)
  draw()
}
run <- function() {
  done <- FALSE
  collected_warnings <- character()
  on.exit({
    writeLines(if (done) "complete" else "incomplete", file.path(out, "run_status.txt"))
    writeLines(capture.output(sessionInfo()), file.path(out, "sessionInfo.txt"))
    writeLines(unique(collected_warnings), file.path(out, "warnings.txt"))
  })
  writeLines("running", file.path(out, "run_status.txt"))
  writeLines(paste(commandArgs(), collapse = "\n"), file.path(out, "command_args.txt"))
  opts$resolved_min_samples <- as.character(inp$min_samples)
  opts$resolved_design <- paste(deparse(inp$design), collapse = "")
  opts$created_utc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
  opts$contrast_direction <- paste(opts$treatment, "minus", opts$control)
  opts$inference <- "Two-sided Wald test of log2FC = 0; BH adjustment; independent filtering enabled"
  opts$effect_filter <- "Posthoc filter on absolute unshrunken log2FC; not an effect-threshold test"
  opts$automatic_count_replacement <- "disabled (minReplicatesForReplace=Inf)"
  write_tsv(data.frame(key = names(opts), value = unlist(opts)), "run_config.tsv")
  files <- normalizePath(c(opts$counts, opts$samples, script_path,
                          file.path(dirname(script_path), "validation.R")))
  write_tsv(data.frame(path = files, md5 = unname(tools::md5sum(files))), "input_source_checksums.tsv")
  write_tsv(inp$samples, "samples_aligned.tsv")
  matrix_tsv(inp$design_matrix, "design_matrix.tsv", "sample_id")
  if (opts$batch != "none") write_tsv(as.data.frame(table(inp$samples$model_batch,
                                  inp$samples$condition)), "batch_condition_table.tsv")
  work <- function() {
    dds <- DESeqDataSetFromMatrix(inp$counts[inp$keep, , drop = FALSE],
                                  colData = inp$samples, design = inp$design)
    dds <- DESeq(dds, test = "Wald", fitType = "parametric",
                  sfType = opts[["size-factors"]], minReplicatesForReplace = Inf,
                  parallel = FALSE)
    if (is.null(mcols(dds)$betaConv) || anyNA(mcols(dds)$betaConv) || any(!mcols(dds)$betaConv)) {
      fail("One or more coefficient fits did not converge. Inspect the design and count data before rerunning.")
    }
    contrast <- c("condition", opts$treatment, opts$control)
    res <- results(dds, contrast = contrast, alpha = alpha, pAdjustMethod = "BH",
                   independentFiltering = TRUE)
    fit <- as.data.frame(res)
    fit$gene_id <- rownames(fit)
    fit$test_status <- ifelse(is.na(fit$pvalue), "pvalue_unavailable_check_model",
                              ifelse(is.na(fit$padj), "independent_filter", "tested"))
    # Diagnose unavailable p-values; never substitute this diagnostic test for inference.
    if (anyNA(fit$pvalue)) {
      diagnostic <- results(dds, contrast = contrast, alpha = alpha,
                              cooksCutoff = FALSE, independentFiltering = FALSE)
      cooks <- is.na(fit$pvalue) & !is.na(diagnostic$pvalue)
      fit$test_status[cooks] <- "cooks_outlier"
    }
    fit$beta_converged <- as.logical(mcols(dds)$betaConv)
    fit$log2FC_shrunken <- NA_real_
    if (opts$shrink == "apeglm") {
      # Binary condition is the last term of this additive design.
      coef_name <- tail(resultsNames(dds), 1L)
      shrunk <- lfcShrink(dds, coef = coef_name, res = res, type = "apeglm")
      fit$log2FC_shrunken <- shrunk$log2FoldChange
      writeLines(coef_name, file.path(out, "shrinkage_coefficient.txt"))
    }
    all <- data.frame(gene_id = rownames(inp$counts), prefilter_pass = inp$keep)
    j <- match(all$gene_id, fit$gene_id)
    all <- cbind(all, fit[j, setdiff(names(fit), "gene_id"), drop = FALSE])
    rownames(all) <- NULL
    all$test_status[!all$prefilter_pass] <- "removed_low_count"
    all$fdr_significant <- !is.na(all$padj) & all$padj < alpha
    all$selected_posthoc <- all$fdr_significant & !is.na(all$log2FoldChange) &
                            abs(all$log2FoldChange) >= lfc_cut
    all$direction <- ifelse(all$selected_posthoc,
                             ifelse(all$log2FoldChange > 0, "up", "down"), "not_selected")
    all <- all[order(all$padj, all$pvalue, all$gene_id, na.last = TRUE), ]
    write_tsv(all, "results_all_genes.tsv")
    write_tsv(all[all$selected_posthoc, , drop = FALSE], "results_selected_posthoc.tsv")
    write_tsv(data.frame(sample_id = colnames(dds),
                         raw_library_size = colSums(inp$counts),
                         size_factor = sizeFactors(dds)), "sample_qc.tsv")
    matrix_tsv(counts(dds, normalized = TRUE), "normalized_counts_retained.tsv")
    saveRDS(dds, file.path(out, "dds.rds"))
    # Full VST is reliable even when fewer than 1,000 genes pass filtering.
    vsd <- varianceStabilizingTransformation(dds, blind = FALSE)
    saveRDS(vsd, file.path(out, "vst.rds"))
    mat <- assay(vsd)
    matrix_tsv(mat, "vst_values_retained.tsv")
    sdmat <- as.matrix(dist(t(mat)))
    matrix_tsv(sdmat, "sample_distances.tsv", "sample_id")
    pca <- plotPCA(vsd, intgroup = "condition", ntop = min(500L, nrow(vsd)), returnData = TRUE)
    variance <- attr(pca, "percentVar")
    write_tsv(pca, "pca_coordinates.tsv")
    write_tsv(data.frame(component = c("PC1", "PC2"), fraction_variance = variance), "pca_variance.tsv")
    cols <- c("#16877E", "#C65D43")
    pcols <- cols[as.integer(inp$samples$condition)]
    shapes <- if (opts$batch == "none") rep(19L, ncol(dds)) else
      rep(c(16, 17, 15, 18, 8, 3, 4), length.out = nlevels(inp$samples$model_batch))[as.integer(inp$samples$model_batch)]
    save_plot("pca.pdf", function() {
      plot(pca$PC1, pca$PC2, col = pcols, pch = shapes, cex = 1.3,
           xlab = sprintf("PC1 (%.1f%%)", 100 * variance[1]),
           ylab = sprintf("PC2 (%.1f%%)", 100 * variance[2]),
           main = "Sample PCA | VST, top variable genes")
      text(pca$PC1, pca$PC2, labels = rownames(inp$samples), pos = 3, cex = .65)
      legend("topright", legend = levels(inp$samples$condition), col = cols, pch = 19, bty = "n")
      if (opts$batch != "none") legend("bottomright", legend = levels(inp$samples$model_batch),
        pch = rep(c(16, 17, 15, 18, 8, 3, 4), length.out = nlevels(inp$samples$model_batch)),
        title = "Batch", bty = "n", cex = .8)
    })
    save_plot("sample_distances.pdf", function() {
      dend <- as.dendrogram(hclust(as.dist(sdmat)))
      heatmap(sdmat, Rowv = dend, Colv = dend, scale = "none", symm = TRUE,
              col = colorRampPalette(c("#F2F6F3", "#16877E", "#153C47"))(80),
              margins = c(8, 8), main = "Euclidean distances | VST")
    }, width = 8, height = 8)
    save_plot("volcano.pdf", function() {
      valid <- is.finite(all$log2FoldChange) & !is.na(all$padj)
      points <- all[valid, , drop = FALSE]
      if (!nrow(points)) { plot.new(); title("No adjusted p-values available"); return(invisible(NULL)) }
      color <- ifelse(points$direction == "up", "#C65D43",
                       ifelse(points$direction == "down", "#16877E", "#B6C2C4"))
      plot(points$log2FoldChange, -log10(pmax(points$padj, .Machine$double.xmin)),
           pch = 16, cex = .5, col = color, xlab = paste("Unshrunken log2FC:", opts$treatment, "/", opts$control),
           ylab = "-log10(BH adjusted P)", main = "Differential expression | descriptive effect filter")
      abline(v = c(-lfc_cut, lfc_cut), h = -log10(alpha), lty = 2, col = "#74878D")
      legend("topright", legend = c("Up", "Down", "Not selected"),
             col = c("#C65D43", "#16877E", "#B6C2C4"), pch = 16, bty = "n")
    })
    save_plot("ma.pdf", function() plotMA(res, alpha = alpha,
      main = "MA plot | unshrunken effect, BH threshold"))
    save_plot("dispersion.pdf", function() plotDispEsts(dds))
    summary <- c("Run completed.", paste("Direction:", opts$treatment, "minus", opts$control),
      paste("Input genes:", nrow(inp$counts)), paste("Retained genes:", nrow(dds)),
      paste("Genes with available adjusted P:", sum(!is.na(all$padj))),
      paste("BH adjusted P <", alpha, ":", sum(all$fdr_significant)),
      paste("Additional posthoc abs(raw log2FC) >=", lfc_cut, ":", sum(all$selected_posthoc)),
      paste("Dispersion fit:", attr(dispersionFunction(dds), "fitType")),
      "PCA and distances use VST with blind=FALSE. This does not remove batch variation.",
      "The effect-size cutoff is a descriptive posthoc filter, not a test of effects beyond a threshold.",
      "No pathway enrichment, FASTQ alignment or clinical validation is performed.")
    writeLines(summary, file.path(out, "summary.txt"))
    writeLines(capture.output(citation("DESeq2")), file.path(out, "DESeq2_citation.txt"))
    invisible(all)
  }
  answer <- withCallingHandlers(work(), warning = function(w) {
    collected_warnings <<- c(collected_warnings, conditionMessage(w))
  })
  done <- TRUE
  cat("Completed. Results:", out, "\n")
  invisible(answer)
}
tryCatch(run(), error = function(e) {
  writeLines(conditionMessage(e), file.path(out, "error.txt"))
  message("Analysis failed: ", conditionMessage(e)); quit(status = 1L)
})
