# Base-R validation, deliberately separated from DESeq2 fitting.
fail <- function(...) stop(..., call. = FALSE)

validate_inputs <- function(count_path, sample_path, control, treatment,
                            batch_column = "none", min_count = 10,
                            min_samples = NULL) {
  for (p in c(count_path, sample_path)) {
    if (!file.exists(p) || dir.exists(p)) fail("Input file not found: ", p)
  }
  if (identical(control, treatment)) fail("Control and treatment must differ.")
  tab <- read.delim(count_path, check.names = FALSE, stringsAsFactors = FALSE,
                    colClasses = "character", quote = "", comment.char = "")
  if (nrow(tab) < 2L || ncol(tab) < 5L || names(tab)[1L] != "gene_id") {
    fail("Counts need gene_id, at least two genes and four sample columns.")
  }
  if (anyDuplicated(names(tab))) fail("Duplicate count-column names.")
  genes <- tab$gene_id
  if (anyNA(genes) || any(!nzchar(genes)) || any(trimws(genes) != genes) ||
      anyDuplicated(genes)) fail("gene_id values must be unique, nonempty and unpadded.")
  ids <- names(tab)[-1L]
  if (any(!nzchar(ids)) || any(trimws(ids) != ids)) fail("Invalid count sample IDs.")
  raw <- as.matrix(tab[-1L])
  vals <- suppressWarnings(as.numeric(raw))
  if (anyNA(vals) || any(!is.finite(vals)) || any(vals < 0) ||
      any(vals != floor(vals)) || any(vals > .Machine$integer.max)) {
    fail("Counts must be finite nonnegative integers within R's integer range. ",
         "Do not round TPM, FPKM, transformed or estimated counts.")
  }
  counts <- matrix(as.integer(vals), nrow = nrow(tab), dimnames = list(genes, ids))
  if (any(colSums(counts) == 0)) fail("A sample has a zero library size.")
  meta <- read.delim(sample_path, check.names = FALSE, stringsAsFactors = FALSE,
                     colClasses = "character", quote = "", comment.char = "")
  if (anyDuplicated(names(meta)) || !all(c("sample_id", "condition") %in% names(meta))) {
    fail("Metadata needs unique columns including sample_id and condition.")
  }
  if (anyNA(meta$sample_id) || any(!nzchar(meta$sample_id)) ||
      any(trimws(meta$sample_id) != meta$sample_id) || anyDuplicated(meta$sample_id)) {
    fail("Metadata sample_id values must be unique, nonempty and unpadded.")
  }
  if (!setequal(ids, meta$sample_id)) {
    fail("Count columns and metadata sample_id values must match exactly; no silent dropping.")
  }
  # Alignment is by sample ID, never by the accidental input row order.
  meta <- meta[match(ids, meta$sample_id), , drop = FALSE]
  rownames(meta) <- meta$sample_id
  if (anyNA(meta$condition) || !setequal(unique(meta$condition), c(control, treatment))) {
    fail("This template requires exactly the two named condition levels.")
  }
  meta$condition <- factor(meta$condition, levels = c(control, treatment))
  group_sizes <- table(meta$condition)
  if (any(group_sizes < 2L)) fail("At least two independent biological replicates per group are required.")
  if (any(group_sizes < 3L)) warning("Fewer than three biological replicates in a group; precision is limited.")
  formula <- ~ condition
  if (batch_column != "none") {
    if (batch_column %in% c("sample_id", "condition", "model_batch") ||
        !batch_column %in% names(meta)) fail("Use an existing, separate batch column.")
    b <- meta[[batch_column]]
    if (anyNA(b) || any(!nzchar(b)) || any(trimws(b) != b)) fail("Batch values are missing or padded.")
    if (length(unique(b)) < 2L) fail("A batch term requires at least two observed batches; use --batch none.")
    meta$model_batch <- factor(b)
    formula <- ~ model_batch + condition
  }
  mm <- model.matrix(formula, data = meta)
  if (qr(mm)$rank < ncol(mm)) fail("Design is not full rank: batch and condition may be confounded.")
  if (nrow(mm) <= ncol(mm)) fail("No residual degrees of freedom remain in the design.")
  if (is.null(min_samples)) min_samples <- as.integer(min(group_sizes))
  if (length(min_count) != 1L || !is.finite(min_count) || min_count < 1 || min_count != floor(min_count)) {
    fail("min-count must be a positive integer.")
  }
  if (length(min_samples) != 1L || !is.finite(min_samples) || min_samples < 1 ||
      min_samples > ncol(counts) || min_samples != floor(min_samples)) fail("Invalid min-samples.")
  keep <- rowSums(counts >= min_count) >= min_samples
  if (sum(keep) < 2L) fail("Fewer than two genes remain after the count filter.")
  list(counts = counts, samples = meta, design = formula, design_matrix = mm,
       keep = keep, min_samples = min_samples, min_count = min_count,
       group_sizes = group_sizes)
}
