#!/usr/bin/env Rscript
# Installs packages for this R version. Does not claim to lock the environment.
options(repos = c(CRAN = "https://cloud.r-project.org"))
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
pkgs <- "DESeq2"
if ("--with-apeglm" %in% commandArgs(trailingOnly = TRUE)) pkgs <- c(pkgs, "apeglm")
BiocManager::install(pkgs, ask = FALSE, update = FALSE)
print(BiocManager::version())
print(BiocManager::valid())
sessionInfo()
