# Validation record

Prepared: 28 October 2026.

| Check | Status |
|---|---|
| R/DESeq2 execution | **Not run**: Rscript is not installed in the authoring environment |
| R validation and smoke tests | Included; **not run** here |
| Synthetic input shape and nonnegative-integer counts | Checked using Python |
| Unique feature/sample IDs and metadata alignment | Checked using Python |
| Group replication and balanced batch design | Checked using Python |
| Full-rank design and nonzero library sizes | Checked using Python |
| Regenerating committed demo inputs | Checked; byte-identical with the included generator in this environment |
| ZIP contents and file readability | Checked |

No PDF analysis plots, fitted objects or empirical performance measurements are
bundled. These are generated only by a successful R run.

Before public claims of validation, run from the repository root:

```sh
Rscript scripts/setup.R
Rscript tests/test_validation.R
Rscript tests/smoke_test.R
```

Review warnings and generated plots, then append the R version, package versions,
date, commands, outcomes and any changes here. Retain an actual `sessionInfo.txt`.
Optional apeglm shrinkage requires its own successful execution check.
