#!/usr/bin/env Rscript
# Run from the repository root; these tests need only base R.
source("scripts/validation.R")
td <- tempfile("rnaseq-validation-"); dir.create(td)
on.exit_cleanup <- function() unlink(td, recursive = TRUE)
expect_error <- function(expr, fragment) {
  err <- tryCatch({ force(expr); NULL }, error = identity)
  if (is.null(err) || !grepl(fragment, conditionMessage(err), fixed = TRUE)) {
    stop("Expected error containing: ", fragment)
  }
}
counts <- "data/demo/counts.tsv"; samples <- "data/demo/samples.tsv"
ref <- validate_inputs(counts, samples, "control", "treated", "batch")
stopifnot(ncol(ref$counts) == 8L, nrow(ref$counts) == 2000L,
          all(!ref$keep[1981:2000]), qr(ref$design_matrix)$rank == 3L)
meta <- read.delim(samples, check.names = FALSE)
shuffled <- file.path(td, "shuffled.tsv")
write.table(meta[c(8, 3, 1, 7, 5, 2, 6, 4), ], shuffled,
             sep = "\t", row.names = FALSE, quote = FALSE)
aligned <- validate_inputs(counts, shuffled, "control", "treated", "batch")
stopifnot(identical(ref$samples, aligned$samples), identical(ref$counts, aligned$counts))
bad <- file.path(td, "bad.tsv")
meta$batch <- meta$condition
write.table(meta, bad, sep = "\t", row.names = FALSE, quote = FALSE)
expect_error(validate_inputs(counts, bad, "control", "treated", "batch"), "not full rank")
ct <- read.delim(counts, check.names = FALSE)
ct[1, 2] <- 1.5
write.table(ct, bad, sep = "\t", row.names = FALSE, quote = FALSE)
expect_error(validate_inputs(bad, samples, "control", "treated"), "nonnegative integers")
ct[1, 2] <- 1L; ct$gene_id[2] <- ct$gene_id[1]
write.table(ct, bad, sep = "\t", row.names = FALSE, quote = FALSE)
expect_error(validate_inputs(bad, samples, "control", "treated"), "gene_id values")
meta <- read.delim(samples, check.names = FALSE); meta$sample_id[1] <- "unmatched"
write.table(meta, bad, sep = "\t", row.names = FALSE, quote = FALSE)
expect_error(validate_inputs(counts, bad, "control", "treated"), "match exactly")
on.exit_cleanup()
cat("Validation tests passed: ID alignment, confounding, fractional counts, duplicate genes, missing sample IDs.\n")
