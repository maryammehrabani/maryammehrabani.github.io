#!/usr/bin/env Rscript
# Requires DESeq2. Run from the repository root after setup.R.
out <- tempfile("rnaseq-smoke-")
log <- tempfile("rnaseq-smoke-log-")
args <- c("scripts/run_deseq2.R", "--counts", "data/demo/counts.tsv",
           "--samples", "data/demo/samples.tsv", "--control", "control",
           "--treatment", "treated", "--batch", "batch", "--out", out)
status <- system2(file.path(R.home("bin"), "Rscript"), shQuote(args), stdout = log, stderr = log)
if (status != 0L) { cat(readLines(log), sep = "\n"); stop("Smoke analysis failed.") }
stopifnot(identical(readLines(file.path(out, "run_status.txt")), "complete"))
tab <- read.delim(file.path(out, "results_all_genes.tsv"), check.names = FALSE)
stopifnot(nrow(tab) == 2000L, !anyDuplicated(tab$gene_id),
          sum(!is.na(tab$pvalue)) > 1000L,
          all(tab$test_status[tab$gene_id %in% sprintf("DEMO%05d", 1981:2000)] == "removed_low_count"))
for (name in c("pca.pdf", "sample_distances.pdf", "volcano.pdf", "ma.pdf",
                "dispersion.pdf", "dds.rds", "sessionInfo.txt", "input_source_checksums.tsv")) {
  stopifnot(file.exists(file.path(out, name)), file.info(file.path(out, name))$size > 0)
}
cat("End-to-end smoke test passed. Inspect plots and warnings in:", out, "\n")
